library(fExtremes)
library(Hmisc)

data=read.table("/gpfs/group/keller/home10/POLA_SL/SL_analysis_III/hourly_SLanom.ascii")
#data=read.table("../format_sla.txt")
  sl_in=data[,2]   # column 2

ed=ecdf(sl_in)

### Thin data for easier plotting
### Retain extreme values

sl_sort=sort(sl_in,decreasing=FALSE)
xf=length(sl_sort)
xi=xf-999
print(xf)
print(xi)

sl=array(NA,dim=10000)
sl[1:1000]=sl_sort[xi:xf]

sl[1001:10000]=sample(sl_sort[1:xi],replace=FALSE)


n=10000000


# xi-shape, mu-location, beta-scale
d1=rgev(n, xi = -0.3047, mu = -175.735, beta = 516.769)
d2=rgev(n, xi = -0.3047, mu = -175.735, beta = 533)

e1=ecdf(d1)
e2=ecdf(d2)

x=seq(-1500,1600,length.out=100000)
print(x)

t1=e1(x)
t2=e2(x)

td=ed(sl)

s1=1-t1
s2=1-t2
sd=1-td

pdf(file="figure4_revised_v3.pdf")
plot(sl,sd,type="p",col="red",
#  cex=1.5,log="y",ylim=c(0.0000001,1.),
  cex=1.5,log="y",ylim=c(0.0000001,0.5),
  xlim=c(0,1600),
  ylab="log(1-cdf)",xlab="Hourly sea level anomaly [mm]"
)

axis(2,at=c(1e-7,1e-6,1e-5,1e-4,1e-3,1e-2,1e-1,1),
  lab=c("","","","","","","",""))


lines(x,s1,type="l",col="black",lwd=4)
lines(x,s2,type="l",col="blue",lwd=4)

legend(x="bottomleft",
       inset=c(0.1,0.1),
       legend=c("Observations","GEV distribution (psi=517)","GEV distribution (psi=533)"),
       col=c("red","black","blue"),
       lty=c("solid","solid","solid"),
       lwd=c(3,3,3)
       )

dev.off()
